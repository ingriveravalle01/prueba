﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ConectarDatos;

namespace miwebApi.Controllers
{
    public class UsuariosController : ApiController
    {
        private UsuariosEntities dbContext = new UsuariosEntities();

        [HttpGet]
        public IEnumerable<usuario> Get()
        {
            using (UsuariosEntities usuariosEntities = new UsuariosEntities())
            {
                return usuariosEntities.usuarios.ToList();
            }
        }


        [HttpGet]
        public usuario Get(int id)
        {
            using (UsuariosEntities usuariosEntities = new UsuariosEntities())
            {
                return usuariosEntities.usuarios.FirstOrDefault(x => x.int_id == id);
            }
        }

        [HttpPost]
        public IHttpActionResult AgregarUsuario([FromBody]usuario usu)
        {
            if (ModelState.IsValid)
            {
                dbContext.usuarios.Add(usu);
                dbContext.SaveChanges();
                return Ok(usu);
            }
            else
            {
                return BadRequest();
            }
        }

        [HttpPut]
        public IHttpActionResult ActualizarUsuario(int id, [FromBody]usuario usu)
        {
            if (ModelState.IsValid)
            {
                var UsuarioExiste = dbContext.usuarios.Count(c => c.int_id == id) > 0;
                if (UsuarioExiste)
                {
                    dbContext.Entry(usu).State = System.Data.Entity.EntityState.Modified;
                    dbContext.SaveChanges();
                    return Ok();
                }
                else
                {
                    return NotFound();
                }
            }
            else
            {
                return BadRequest();
            }
        }

        [HttpDelete]
        public IHttpActionResult EliminarUsuario(int id)
        {
            var usu = dbContext.usuarios.Find(id);
            if (usu != null)
            {
                dbContext.usuarios.Remove(usu);
                dbContext.SaveChanges();
                return Ok(usu);

            }
            else
            {
                return NotFound();
            }

        }

    }
}
