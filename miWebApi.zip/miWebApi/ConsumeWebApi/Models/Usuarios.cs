﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ConsumeWebApi.Models
{
    public class Usuarios
    {
        public int int_id { get; set; }
        public string str_status { get; set; }
        public Nullable<System.DateTime> dat_fecha { get; set; }
        public string str_nombre { get; set; }
        public string str_direccion { get; set; }
        public string str_departamento { get; set; }
        public Nullable<int> int_telefono { get; set; }
    }
}