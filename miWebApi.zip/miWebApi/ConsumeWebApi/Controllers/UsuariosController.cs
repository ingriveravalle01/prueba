﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using ConsumeWebApi.Models;
using Newtonsoft.Json;

namespace ConsumeWebApi.Controllers
{
    public class UsuariosController : Controller
    {

        string BaseUrl = "http://localhost:55654/";
        // GET: Usuarios
        public async Task<ActionResult> Index()
        {
            List<Usuarios> Empinfo = new List<Usuarios>();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(BaseUrl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                //llama a todos los usuarios utilizando el hhtpclient
                HttpResponseMessage Res = await client.GetAsync("api/usuarios/");
                if(Res.IsSuccessStatusCode)
                {
                    var EmpResponse = Res.Content.ReadAsStringAsync().Result;
                    Empinfo = JsonConvert.DeserializeObject<List<Usuarios>>(EmpResponse);
                }

                return View(Empinfo);
            }
        }

        //Crear usuario
        public ActionResult create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult create(Usuarios usuarios)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(BaseUrl+ "api/usuarios/");
                var postTask = client.PostAsJsonAsync<Usuarios>("usuarios", usuarios);
                postTask.Wait();
                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }

            ModelState.AddModelError(string.Empty, "Error, contacte al administrador");
            return View(usuarios);
        }

       //Actualizar Usuario
        public ActionResult Edit(int id)
        {
            Usuarios usuarios = null;
                
             using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(BaseUrl);
                var responseTask =  client.GetAsync("api/usuarios/"+id.ToString());
                responseTask.Wait();                      
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<Usuarios>();
                    readTask.Wait();
                    usuarios = readTask.Result;                   
                }
            }

            return View(usuarios);
        }

        [HttpPost]
        public ActionResult Edit(Usuarios usuarios)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(BaseUrl);
                var putTask = client.PutAsJsonAsync($"api/usuarios/{usuarios.int_id}",usuarios);
                putTask.Wait();
                var result = putTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }

            return View(usuarios);
        }

        //Eliminar Usuario

        public ActionResult Delete(int id)
        {
            Usuarios usuarios = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(BaseUrl);
                //HTTPGET
                var responseTask = client.GetAsync("api/usuarios/" + id.ToString());
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<Usuarios>();
                    readTask.Wait();
                    usuarios = readTask.Result;
                }
            }

            return View(usuarios);
        }

        [HttpPost]
        public ActionResult Delete(Usuarios usuarios, int id)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(BaseUrl);
                //HTTP-DELETE
                var deleteTask = client.DeleteAsync($"api/usuarios/"+ id.ToString());
                deleteTask.Wait();
                var result = deleteTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }

            return View(usuarios);
        }
    }
}